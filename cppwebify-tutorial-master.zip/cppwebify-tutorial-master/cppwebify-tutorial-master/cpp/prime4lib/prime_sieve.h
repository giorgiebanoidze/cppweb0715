
extern "C" {
    int do_primesieve(int argc, char *argv[], void * out);

    int generate_primes(int under, void * out);
}
